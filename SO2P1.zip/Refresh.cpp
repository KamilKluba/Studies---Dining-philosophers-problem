#include "Refresh.h"
#include <cstdlib>
#include <ncurses.h>
#include <thread>
#include <unistd.h>
#include <iostream>

using namespace std;


Refresh::Refresh(Philosopher** philosopher, int n){
	this->philosopher = philosopher;
	this->n = n;
	kill = false;
}

void Refresh::refreshScreen(){
	cout<<"cokolwiek xd";
	int refresh = 0;
	while(!kill){
		system("clear");
		cout << "Odświeżenie numer: " << refresh << endl;
		refresh++;
		for (int i = 0; i < n; i++){
			cout << philosopher[i]->getPhilosopherDesc() << endl;
			cout << philosopher[i]->getForkLeft().getForkDesc() << endl;
			cout << philosopher[i]->getForkRight().getForkDesc() << endl;
			cout << endl;
		}

		usleep(100000);
	}

	return;
}