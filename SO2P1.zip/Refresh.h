#include <cstdlib>
#include <ncurses.h>
#include <thread>
#include <unistd.h>
#include "Philosopher.h"

using namespace std;

#ifndef REFRESH_H
#define REFRESH_H

class Refresh{
public:
	int n;
	Philosopher** philosopher;
	bool kill;

	Refresh(Philosopher** philosopher, int n);
	~Refresh();

	void refreshScreen();
};

#endif // REFRESH_H