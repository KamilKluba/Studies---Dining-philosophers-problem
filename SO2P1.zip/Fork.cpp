#include "Fork.h"
#include <string>

using namespace std;

Fork::Fork(int id){
	this->id = id;
	this->occupied = false;
	this->philosopherId = 0;
}

Fork::~Fork(){
}

int Fork::getId(){
	return id;
}

void Fork::setId(int id){
	this->id = id;
}

void Fork::setOccupied(bool occupied){
	this->occupied = occupied;
}

bool Fork::getOccupied(){
	return occupied;
}

void Fork::setPhilosopherId(int philosopherId){
	this->philosopherId = philosopherId;
}

int Fork::getPhilisopherId(){
	return philosopherId;
}

string Fork::getForkDesc(){
	string s;
	s.append("  Widelec ");
	s.append(to_string(id));
	s.append(" jest ");

	if(occupied){
		s.append("zajety.");
	}
	else{
		s.append("wolny.");
	}

	return s;
}