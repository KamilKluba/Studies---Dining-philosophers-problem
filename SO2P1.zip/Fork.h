#include <string>

#ifndef FORK_H
#define FORK_H

using namespace std;

class Fork{
private:
	int id;
	bool occupied;
	int philosopherId;

public:
	Fork(int id);
	~Fork();
	int getId();
	void setId(int id);
	void setOccupied(bool occupied);
	bool getOccupied();
	void setPhilosopherId(int philosopherID);
	int getPhilisopherId();
	string getForkDesc();
};

#endif //FORK_H