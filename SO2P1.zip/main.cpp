#include <iostream>
#include "Philosopher.h"
#include "Fork.h"
#include "Refresh.h"
#include <cstdlib>
#include <ncurses.h>
#include <thread>
#include <unistd.h>


using namespace std;

int main(){
	int n;
	cin >> n;
	Philosopher** philosopher = new Philosopher*[n];
	Fork* fork[2 * n];
	thread* threads = new thread[n + 1];

	for (int i = 0; i < 2 * n; i++){
		fork[i] = new Fork(i + 1);
	}

	for (int i = 0; i < n; i++){
		philosopher[i] = new Philosopher(i + 1);
		philosopher[i]->setForkLeft(fork[2 * i]);
		philosopher[i]->setForkRight(fork[2 * i + 1]);

		threads[i] = thread(&Philosopher::lifeCycle, philosopher[i]);
	}

	Refresh* refresh = new Refresh(philosopher, n);
	threads[n] = thread(&Refresh::refreshScreen, refresh);

	usleep(10000000);

	for (int i = 0; i < n; i++){
		philosopher[i]->setAlive(false);
	}
	usleep(6000000);

	refresh->kill = true;
}

