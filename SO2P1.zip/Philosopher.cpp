#include "Philosopher.h"
#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <ncurses.h>
#include <string>

using namespace std;

Philosopher::Philosopher(int id){
	this->id = id;
	eatingTime = 3.5;
	eatingMargin = 1;
	philosophizingTime = 3;
	philosophizingMargin = 1;
	isAlive = true;
	state = 0;
}

Philosopher::~Philosopher(){

}

int Philosopher::getId(){
	return id;
}

void Philosopher::setId(int id){
	this->id = id;
}

double Philosopher::getEatingTime(){
	return eatingTime;
}

void Philosopher::setEatingTime(double eatingTime){
	this->eatingTime = eatingTime;
}
double Philosopher::getPhilosophizingTime(){
	return philosophizingTime;
}

void Philosopher::setPhilosophizingTime(double philosophizingTime){
	this->philosophizingTime = philosophizingTime;
}

double Philosopher::getEatingMargin(){
	return eatingTime;
}

void Philosopher::setEatingMargin(double eatingMargin){
	this->eatingMargin = eatingMargin;
}
double Philosopher::getPhilosophizingMargin(){
	return philosophizingMargin;
}

void Philosopher::setPhilosophizingMargin(double philosophizingMargin){
	this->philosophizingMargin = philosophizingMargin;
}

bool Philosopher::getAlive(){
	return isAlive;
}

void Philosopher::setAlive(bool isAlive){
	this->isAlive = isAlive;
}

void Philosopher::setForkLeft(Fork* forkLeft){
	this->forkLeft = forkLeft;
}

Fork Philosopher::getForkLeft(){
	return *forkLeft;
}

void Philosopher::setForkRight(Fork* forkRight){
	this->forkRight = forkRight;
}

Fork Philosopher::getForkRight(){
	return *forkRight;
}

int Philosopher::getState(){
	return state;
}

void Philosopher::setState(int state){
	this->state = state;
}

string Philosopher::getPhilosopherDesc(){
	string desc;
	desc.append("Filozof ");
	desc.append(to_string(id));

	if(state == 0)
		desc.append(" bierze widelce.");
	if(state == 1)
		desc.append(" je.");
	else
		desc.append(" rozmyśla.");

	return desc;
}

void Philosopher::lifeCycle(){
	srand(time(NULL));
	while(isAlive){
		state = 0;
		if (!forkLeft->getOccupied())
			forkLeft->setOccupied(true);
		if (!forkRight->getOccupied())
			forkRight->setOccupied(true);

		state = 1;
		usleep((int)(eatingTime * 1000000) + 2 * (int)rand() % ((int)(eatingMargin * 1000000)) - (int)(eatingMargin * 1000000));
		forkLeft->setOccupied(false);
		forkRight->setOccupied(false);
		
		state = 2;
		usleep((int)(philosophizingTime * 1000000) + 2 * (int)rand() % ((int)(philosophizingMargin * 1000000)) - (int)(philosophizingMargin * 1000000));
	}

	return;
}