#include <string>

#ifndef PHILOSOPHER_H
#define PHILOSOPHER_H

#include "Fork.h"

class Philosopher
{
private:
	int id;
	double eatingTime;
	double eatingMargin;
	double philosophizingTime;
	double philosophizingMargin;
	bool isAlive;
	Fork* forkLeft;
	Fork* forkRight;
	int state; //0 rozmysla 1 je

public:
	Philosopher(int id);
	~Philosopher();
	
	int getId();
	void setId(int id);
	double getEatingTime();
	void setEatingTime(double eatingTime);
	double getPhilosophizingTime();
	void setPhilosophizingTime(double philosophizingTime);
	double getEatingMargin();
	void setEatingMargin(double eatingMargin);
	double getPhilosophizingMargin();
	void setPhilosophizingMargin(double philosophizingMargin);
	bool getAlive();
	void setAlive(bool isAlive);
	void setForkLeft(Fork* forkLeft);
	Fork getForkLeft();
	void setForkRight(Fork* forkRight);
	Fork getForkRight();
	int getState();
	void setState(int state);
	void lifeCycle();
	string getPhilosopherDesc();
};

#endif // PHILOSOPHER_H